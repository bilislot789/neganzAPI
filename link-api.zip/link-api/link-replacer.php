<?php
/**
 * Plugin Name: Link Api
 * Description: Replace old links with link api
 * Version: 1.1
 * Author: Nox
 * Text Domain: link-replacer
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

class Link_Replacer {
    private $default_api_url = 'https://raw.githubusercontent.com/bilislot789/neganzAPI/refs/heads/main/linksReg.json';
    private $default_link = 'https://go888.pages.dev/';
    private $default_old_link = 'https://bit.ly/4cQtnx1';

    private $options;
    private $transient_name = 'link_replacer_api_data';
    private $new_link;

    public function __construct() {
        add_action('admin_menu', array($this, 'add_settings_page'));
        add_action('admin_init', array($this, 'register_settings'));
        
        // Initialize options
        $this->options = get_option('link_replacer_options', array(
            'old_link' => $this->default_old_link,
            'api_url' => $this->default_api_url,
        ));
        
        // Get replacement link once for the request
        $this->new_link = $this->get_replacement_link();
        
        // Add content filter to replace links on output
        add_filter('the_content', array($this, 'replace_content_links'));
        
        // Buffer for replacing links in entire page
        add_action('init', array($this, 'start_output_buffer'));
    }

    public function start_output_buffer() {
        // Only apply on front-end, not admin pages
        if (!is_admin()) {
            ob_start(array($this, 'process_output_buffer'));
        }
    }

    public function process_output_buffer($buffer) {
        $old_link = isset($this->options['old_link']) ? $this->options['old_link'] : '';
        if (empty($old_link)) {
            return $buffer;
        }

        // Use server-side replacement with DOMDocument for HTML parsing
        if (extension_loaded('dom')) {
            // Only process if the buffer appears to be HTML
            if (preg_match('/<html[^>]*>/i', $buffer)) {
                $dom = new DOMDocument();
                
                // Attempt to handle UTF-8 encoding issues
                $buffer = mb_convert_encoding($buffer, 'HTML-ENTITIES', 'UTF-8');
                
                // Suppress warnings because DOMDocument is strict
                libxml_use_internal_errors(true);
                $dom->loadHTML($buffer, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
                libxml_clear_errors();
                
                // Find and replace all links
                $links = $dom->getElementsByTagName('a');
                $links_to_change = array();
                
                // We need to collect links first because the NodeList is live
                // and would change if we modified nodes during iteration
                foreach ($links as $link) {
                    if ($link->hasAttribute('href')) {
                        $href = $link->getAttribute('href');
                        if ($href === $old_link) {
                            $links_to_change[] = $link;
                        }
                    }
                }
                
                // Now replace the collected links
                foreach ($links_to_change as $link) {
                    $link->setAttribute('href', $this->new_link);
                }
                
                // Save the HTML
                $buffer = $dom->saveHTML();
            }
        } else {
            // Fallback to regex replacement if DOM extension is not available
            $buffer = preg_replace(
                '/<a([^>]*)href=["\']' . preg_quote($old_link, '/') . '["\']([^>]*)>/i',
                '<a$1href="' . esc_attr($this->new_link) . '"$2>',
                $buffer
            );
        }

        return $buffer;
    }

    public function replace_content_links($content) {
        $old_link = isset($this->options['old_link']) ? $this->options['old_link'] : '';
        if (empty($old_link)) {
            return $content;
        }

        // Replace links in post content
        $content = preg_replace(
            '/<a([^>]*)href=["\']' . preg_quote($old_link, '/') . '["\']([^>]*)>/i',
            '<a$1href="' . esc_attr($this->new_link) . '"$2>',
            $content
        );

        return $content;
    }

    public function add_settings_page() {
        add_options_page(
            'Link Replacer Settings',
            'Link Replacer',
            'manage_options',
            'link-replacer',
            array($this, 'settings_page_content')
        );
    }

    public function register_settings() {
        register_setting('link_replacer_options_group', 'link_replacer_options');
        
        add_settings_section(
            'link_replacer_main_section',
            'Link Replacer Settings',
            array($this, 'settings_section_callback'),
            'link-replacer'
        );
        
        add_settings_field(
            'old_link',
            'Old Link to Replace',
            array($this, 'old_link_callback'),
            'link-replacer',
            'link_replacer_main_section'
        );
        
        add_settings_field(
            'api_url',
            'API URL',
            array($this, 'api_url_callback'),
            'link-replacer',
            'link_replacer_main_section'
        );
    }

    public function settings_section_callback() {
        echo '<p>Enter the old link that should be replaced with a new randomized link from the API.</p>';
    }

    public function old_link_callback() {
        $old_link = isset($this->options['old_link']) ? $this->options['old_link'] : '';
        echo '<input type="text" id="old_link" name="link_replacer_options[old_link]" value="' . esc_attr($old_link) . '" class="regular-text" />';
    }
    
    public function api_url_callback() {
        $api_url = isset($this->options['api_url']) ? $this->options['api_url'] : $this->default_api_url;
        echo '<input type="text" id="api_url" name="link_replacer_options[api_url]" value="' . esc_attr($api_url) . '" class="regular-text" />';
        echo '<p class="description">Enter the URL for the API that provides the replacement links.</p>';
    }

    public function settings_page_content() {
        if (!current_user_can('manage_options')) {
            return;
        }
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            <form action="options.php" method="post">
                <?php
                settings_fields('link_replacer_options_group');
                do_settings_sections('link-replacer');
                submit_button('Save Settings');
                ?>
            </form>
            
            <div class="card">
                <h2>Current Link Information</h2>
                <p><strong>Old Link:</strong> <?php echo esc_html($this->options['old_link']); ?></p>
                <p><strong>API URL:</strong> <?php echo esc_html(isset($this->options['api_url']) ? $this->options['api_url'] : $this->default_api_url); ?></p>
                <p><strong>New Link:</strong> <?php echo esc_html($this->new_link); ?></p>
                <p><small>Note: The new link is randomly selected from the API and cached for 24 hours.</small></p>
                
                <form method="post" action="">
                    <?php wp_nonce_field('clear_link_cache', 'link_replacer_nonce'); ?>
                    <input type="submit" name="clear_cache" class="button button-secondary" value="Clear API Cache">
                </form>
                <?php
                // Handle cache clearing
                if (isset($_POST['clear_cache']) && 
                    isset($_POST['link_replacer_nonce']) && 
                    wp_verify_nonce($_POST['link_replacer_nonce'], 'clear_link_cache')) {
                    delete_transient($this->transient_name);
                    echo '<div class="notice notice-success inline"><p>Cache cleared successfully!</p></div>';
                }
                ?>
            </div>
        </div>
        <?php
    }

    public function get_replacement_link() {
        // Check if we have cached data
        $api_data = get_transient($this->transient_name);
        
        if ($api_data === false) {
            // Cache doesn't exist or expired, fetch from API
            try {
                $api_url = isset($this->options['api_url']) ? $this->options['api_url'] : $this->default_api_url;
                $response = wp_remote_get($api_url);
                
                if (is_wp_error($response)) {
                    return $this->default_link;
                }
                
                $body = wp_remote_retrieve_body($response);
                $api_data = json_decode($body, true);
                
                // Cache for 24 hours (86400 seconds)
                set_transient($this->transient_name, $api_data, 86400);
            } catch (Exception $e) {
                return $this->default_link;
            }
        }
        
        // Get random link from API data
        if (isset($api_data['links']) && !empty($api_data['links'])) {
            $random_link = $api_data['links'][array_rand($api_data['links'])];
            return $random_link;
        }
        
        return $this->default_link;
    }
}

// Initialize the plugin
new Link_Replacer();