<?php
/**
 * Plugin Name: Link Api
 * Description: Replace old links with link api
 * Version: 1.0
 * Author: Nox
 * Text Domain: link-replacer
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

class Link_Replacer {
    private $api_url = 'https://raw.githubusercontent.com/bilislot789/neganzAPI/refs/heads/main/linksReg.json';
    private $default_link = 'https://go888.pages.dev/';
    private $default_old_link = 'https://bit.ly/4cQtnx1';

    private $options;
    private $transient_name = 'link_replacer_api_data';

    public function __construct() {
        add_action('admin_menu', array($this, 'add_settings_page'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('wp_footer', array($this, 'replace_links'));
        
        // Initialize options
        $this->options = get_option('link_replacer_options', array(
            'old_link' => $this->default_old_link,
        ));
    }

    public function add_settings_page() {
        add_options_page(
            'Link Replacer Settings',
            'Link Replacer',
            'manage_options',
            'link-replacer',
            array($this, 'settings_page_content')
        );
    }

    public function register_settings() {
        register_setting('link_replacer_options_group', 'link_replacer_options');
        
        add_settings_section(
            'link_replacer_main_section',
            'Link Replacer Settings',
            array($this, 'settings_section_callback'),
            'link-replacer'
        );
        
        add_settings_field(
            'old_link',
            'Old Link to Replace',
            array($this, 'old_link_callback'),
            'link-replacer',
            'link_replacer_main_section'
        );
    }

    public function settings_section_callback() {
        echo '<p>Enter the old link that should be replaced with a new randomized link from the API.</p>';
    }

    public function old_link_callback() {
        $old_link = isset($this->options['old_link']) ? $this->options['old_link'] : '';
        echo '<input type="text" id="old_link" name="link_replacer_options[old_link]" value="' . esc_attr($old_link) . '" class="regular-text" />';
    }

    public function settings_page_content() {
        if (!current_user_can('manage_options')) {
            return;
        }
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            <form action="options.php" method="post">
                <?php
                settings_fields('link_replacer_options_group');
                do_settings_sections('link-replacer');
                submit_button('Save Settings');
                ?>
            </form>
            
            <div class="card">
                <h2>Current Link Information</h2>
                <p><strong>Old Link:</strong> <?php echo esc_html($this->options['old_link']); ?></p>
                <p><strong>New Link:</strong> <?php echo esc_html($this->get_replacement_link()); ?></p>
                <p><small>Note: The new link is randomly selected from the API and cached for 24 hours.</small></p>
                
                <form method="post" action="">
                    <?php wp_nonce_field('clear_link_cache', 'link_replacer_nonce'); ?>
                    <input type="submit" name="clear_cache" class="button button-secondary" value="Clear API Cache">
                </form>
                <?php
                // Handle cache clearing
                if (isset($_POST['clear_cache']) && 
                    isset($_POST['link_replacer_nonce']) && 
                    wp_verify_nonce($_POST['link_replacer_nonce'], 'clear_link_cache')) {
                    delete_transient($this->transient_name);
                    echo '<div class="notice notice-success inline"><p>Cache cleared successfully!</p></div>';
                }
                ?>
            </div>
        </div>
        <?php
    }

    public function get_replacement_link() {
        // Check if we have cached data
        $api_data = get_transient($this->transient_name);
        
        if ($api_data === false) {
            // Cache doesn't exist or expired, fetch from API
            try {
                $response = wp_remote_get($this->api_url);
                
                if (is_wp_error($response)) {
                    return $this->default_link;
                }
                
                $body = wp_remote_retrieve_body($response);
                $api_data = json_decode($body, true);
                
                // Cache for 24 hours (86400 seconds)
                set_transient($this->transient_name, $api_data, 86400);
            } catch (Exception $e) {
                return $this->default_link;
            }
        }
        
        // Get random link from API data
        if (isset($api_data['links']) && !empty($api_data['links'])) {
            $random_link = $api_data['links'][array_rand($api_data['links'])];
            return $random_link;
        }
        
        return $this->default_link;
    }

    public function replace_links() {
        $old_link = isset($this->options['old_link']) ? $this->options['old_link'] : '';
        if (empty($old_link)) {
            return;
        }
        
        $new_link = $this->get_replacement_link();
        
        // Add JavaScript to replace links in the frontend
        ?>
        <script type="text/javascript">
        (function() {
            const oldLink = <?php echo json_encode($old_link); ?>;
            const newLink = <?php echo json_encode($new_link); ?>;
            
            function replaceLinks() {
                const links = document.getElementsByTagName('a');
                for (let i = 0; i < links.length; i++) {
                    if (links[i].href === oldLink) {
                        links[i].href = newLink;
                    }
                }
            }
            
            // Replace links when DOM is loaded
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', replaceLinks);
            } else {
                replaceLinks();
            }
            
            // Also handle dynamically added links
            const originalCreateElement = document.createElement;
            document.createElement = function() {
                const element = originalCreateElement.apply(this, arguments);
                if (arguments[0].toLowerCase() === 'a') {
                    const originalSetAttribute = element.setAttribute;
                    element.setAttribute = function(name, value) {
                        if (name.toLowerCase() === 'href' && value === oldLink) {
                            value = newLink;
                        }
                        return originalSetAttribute.call(this, name, value);
                    };
                }
                return element;
            };
        })();
        </script>
        <?php
    }
}

// Initialize the plugin
new Link_Replacer();